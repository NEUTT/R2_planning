# Contact Us

\htmlonly<div class="row"><div class="span6">\endhtmlonly
# Mailing Lists

 - Email ompl-users@lists.sourceforge.net to write to the OMPL discussion mailing list. You can subscribe to the list and see an archive of previous messages [here](https://lists.sourceforge.net/lists/listinfo/ompl-users).
 - Email ompl-devel@lists.sourceforge.net to contact the core developers. Please use this list only if you have questions that you feel are not appropriate for the ompl-users mailing list.

# Reporting Bugs

To report a bug, please click [here](bitbucketIssues.html).

\htmlonly</div><div class="span6">
<h2>Contact form</h2>
<iframe src="php/html-contact-form.php" width="100%" height="620"></iframe></div></div>
\endhtmlonly
