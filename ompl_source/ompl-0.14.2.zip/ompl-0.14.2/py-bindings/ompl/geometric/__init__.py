from ompl import base
from ompl.geometric._geometric import *

# call ompl.initializePlannerLists() to properly initialize this variable
# with a dictionary of dictionaries, containing planners and associated
# parameter info
planners = None
